<?php
   define('DB_SERVER', 'mathlab.utsc.utoronto.ca');
   define('DB_USERNAME', 'shethsh1');
   define('DB_PASSWORD', 'shethsh1');
   define('DB_DATABASE', 'cscb20w18_shethsh1');
   $db = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);


?>